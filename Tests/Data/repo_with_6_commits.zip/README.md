# Victor

A little helper for git history
